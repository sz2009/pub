/*
*****************************************************************************
* COPYRIGHT AND WARRANTY INFORMATION
*
* Copyright 2003, Advanced Audio Video Coding Standard, Part II
*
* DISCLAIMER OF WARRANTY
*
* The contents of this file are subject to the Mozilla Public License
* Version 1.1 (the "License"); you may not use this file except in
* compliance with the License. You may obtain a copy of the License at
* http://www.mozilla.org/MPL/
*
* Software distributed under the License is distributed on an "AS IS"
* basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
* License for the specific language governing rights and limitations under
* the License.
*                     
* THIS IS NOT A GRANT OF PATENT RIGHTS - SEE THE AVS PATENT POLICY.
* The AVS Working Group doesn't represent or warrant that the programs
* furnished here under are free of infringement of any third-party patents.
* Commercial implementations of AVS, including shareware, may be
* subject to royalty fees to patent holders. Information regarding
* the AVS patent policy for standardization procedure is available at 
* AVS Web site http://www.avs.org.cn. Patent Licensing is outside
* of AVS Working Group.
*
* The Original Code is Reference Software for China National Standard 
* GB/T 20090.2-2006 (short for AVS-P2 or AVS Video) at version RM52K.
*
* The Initial Developer of the Original Code is Video subgroup of AVS
* Workinggroup (Audio and Video coding Standard Working Group of China).
* Contributors:   Guoping Li,    Siwei Ma,    Jian Lou,    Qiang Wang , 
*   Jianwen Chen,Haiwu Zhao,  Xiaozhen Zheng, Junhao Zheng, Zhiming Wang
* 
******************************************************************************
*/

// ===================================================================================
//  File Name:   bbv.c
//  Description: bbv buffer for rate control
// -----------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------
// Author (core ID)                Time       
// -----------------------------------------------------------------------------------
// ������( hcyin@nscc.cn )       2008.09.18
// -----------------------------------------------------------------------------------
//
// ===================================================================================



#include <stdlib.h>
#include "bbv.h"


/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
BbvBuffer_t* init_bbv_memory(int frame_rate_code, int low_delay, int bbv_buffer_size, int bit_rate_upper, int bit_rate_lower)
{
  BbvBuffer_t *pBbv;
  static float frame_rate_table[] = {23.97f, 24.00f, 25.00f, 29.97f, 30.00f, 50.00f, 59.97f, 60.00f};

  if ( NULL == (pBbv = (struct BbvBuffer_t*)calloc(1, sizeof(BbvBuffer_t))) )
  {
    printf("memory for bbv buffer have error.\n");
    return NULL;
  }
  
  if ( NULL == (pBbv->FrameBits = (int*)calloc(1, 1000000*sizeof(int))) )
  {
    printf("memory for frame bits of bbv buffer have error.\n");
    return NULL;
  }

  pBbv->frame_code_bits = 0;
  pBbv->framerate = frame_rate_table[frame_rate_code - 1];
  pBbv->frm_no = 0;  // ������ŵĵ�һ֡��ÿ��vec���ֺ�ĵ�һ��I֡Ҫ���㡣
  pBbv->bbv_mode = 0;
  pBbv->low_delay = (float)low_delay;      // �������ж���Ӧ�øı�pImg->enc_low_delayֵ������BBVҪ���³�ʼ����
  pBbv->frmout_interval = (float)(1.0/pBbv->framerate);
  pBbv->bitrate = ((bit_rate_upper<<18) + bit_rate_lower)*400;        // bit per second
  pBbv->BBS_size = bbv_buffer_size<<14;
  pBbv->check_continue = 1;
  //pBbv->bbv_delay = (float)(0.5*pBbv->BBS_size/pBbv->bitrate);  // initial delay time of bbv buffer size
  pBbv->currFrm_max_bit = pBbv->BBS_size;
  pBbv->currFrm_min_bit = 0;

  return pBbv;
}


/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void stat_bbv_buffer(BbvBuffer_t* pBbv)
{
  int minBBSsize, minFsize;

  calc_min_BBS_size(pBbv->FrameBits, pBbv->bitrate, pBbv->framerate, pBbv->frm_no, &minBBSsize, &minFsize);
  printf("\nmin bbv_buffer_size in bitstream is %d\n", minBBSsize>>14);
  printf("min initial bbv_delay(0) time is %.4f(s)\n\n", (float)minFsize/pBbv->bitrate);
}


/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
BbvBuffer_t* free_bbv_memory(BbvBuffer_t* pBbv)
{
  free(pBbv->FrameBits);
  pBbv->FrameBits = NULL;
  free(pBbv);
  pBbv = NULL;

  return pBbv;
}


/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void update_bbv(BbvBuffer_t* pBbv, int code_bits)
{
  pBbv->FrameBits[pBbv->frm_no++] = code_bits;
  if ((code_bits < pBbv->currFrm_min_bit) && !pBbv->low_delay && pBbv->check_continue)
  {
    fprintf(p_sreport,"Image NO.%d code bits is %d, underflow lower bound %d\n\n", FrameNum-1, code_bits, pBbv->currFrm_min_bit);
	CSyntax = 0;
    pBbv->check_continue = 0;
  }
  if ((code_bits > pBbv->currFrm_max_bit) && pBbv->check_continue)
  {
    fprintf(p_sreport,"Image NO.%d code bits is %d, overflow upper bound %d\n\n", FrameNum-1, code_bits, pBbv->currFrm_max_bit);
	CSyntax = 0;
    pBbv->check_continue = 0;
  }

  pBbv->bbv_delay += pBbv->frmout_interval - ((float)code_bits)/((float)pBbv->bitrate);
  if (pBbv->bbv_mode) // 0xFFFF
  {
    pBbv->currFrm_max_bit = MIN(pBbv->BBS_size, (int)(pBbv->currFrm_max_bit - code_bits + pBbv->bitrate*pBbv->frmout_interval + 0.5));
    pBbv->currFrm_min_bit = 0;
  } 
  else // not 0xFFFF
  {
    pBbv->currFrm_max_bit = (int)(pBbv->bbv_delay*pBbv->bitrate + 0.5);
    pBbv->currFrm_min_bit = MAX(0, (int)((pBbv->bbv_delay + pBbv->frmout_interval)*pBbv->bitrate - pBbv->BBS_size + 0.5));
  }
}


/*
*************************************************************************
* Function:
* Input:
* Output:
* Return: 
* Attention:
*************************************************************************
*/
void calc_min_BBS_size(int* FrameBits, int BitRate, float FrameRate, int FrameNum, int *Bmin_out, int *Fmin_out)
{
  float B;
  float *Buff1, *Buff2;
  float minbuff;
  float Bmin, Fmin;
  int   i;
  
  Buff1 = (float*)calloc(FrameNum + 1, sizeof(float));
  Buff2 = (float*)calloc(FrameNum,     sizeof(float));
  B = (float)(BitRate*20);

  minbuff = Buff1[FrameNum] = B;
  for (i = FrameNum - 1; i>=0; i--)
  {
    Buff2[i] = Buff1[i + 1] - FrameBits[i];
    if (Buff2[i]< minbuff)
      minbuff = Buff2[i];
    Buff1[i] = Buff2[i] + BitRate/FrameRate;
    if (Buff1[i] > B) 
      Buff1[i] = B;
  }
  Bmin = B - minbuff;
  *Bmin_out = (int)Bmin;

  B = Bmin;
  Fmin = 0;
  Buff1[0] = Fmin;
  for (i = 0; i<FrameNum; i++)
  {
    Buff2[i] = Buff1[i] - FrameBits[i];
    if (Buff2[i]< 0)
    {
      Fmin += (0 - Buff2[i]);
      Buff2[i] = 0;
    }
    Buff1[i+1] = Buff2[i] + BitRate/FrameRate;
    if (Buff1[i+1] > B) 
      Buff1[i+1] = B;
  }
  *Fmin_out = (int)Fmin;

  free(Buff1);
  free(Buff2);
}

